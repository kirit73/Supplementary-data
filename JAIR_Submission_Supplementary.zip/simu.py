import random
import csv
import ollama

# Initialize the game with 1000 balloons
def initialize_game():
    """Initialize the game with 1000 balloons."""
    return [{'pumps': 0, 'status': 'pumping', 'balloon_id': i, 'cashout': False, 'earned': 0} for i in range(1, 1001)]

# Ollama chat model
def chat_with_ollama(prompt, balloon_id):
    """Interact with the Ollama model."""
    # model = ollama.Ollama()  # Initialize the Ollama model (ensure it's installed correctly)
    response = ollama.chat(model="phi3:3.8b-mini-128k-instruct-q5_1", messages=[{"role": "system", "content": prompt}])
    res = response['message']['content'].strip().lower()
    print(res, balloon_id)
    return res

# Simulate the BART game with Ollama model
def play_bart_game():
    """Simulate playing the BART game with LLM using Ollama."""
    game_data = initialize_game()  # Initialize the balloons
    game_results = []
    
    for balloon in game_data:
        balloon_id = balloon['balloon_id']
        accumulated_money = 0
        is_burst = False
        
        while balloon['status'] == 'pumping' and not is_burst:
            # Prompt Ollama for the model's next action (pump or cashout)
            prompt = f"""
                You are playing the Balloon Analogue Risk Task (BART) game.

                In this game, you control a balloon, and your goal is to maximize the money earned from pumping the balloon. 

                - For each pump, you earn $1.
                - The balloon can burst at any time, causing you to lose all the money you have earned for that balloon.
                - Alternatively, you can choose to 'cash out', which will save the money you have earned so far.

                Currently, Balloon {balloon_id} has accumulated ${accumulated_money}. 

                Your decision: Should it pump again or cash out?

                Type 'pump' to pump the balloon and earn $1, or type 'cash out' to stop and safely store the accumulated money.

                DO NOT TYPE ANYTHING ELSE. Your response should be either 'pump' or 'cash out'. Do not add any other text or explanation.

                YOUR ANSWER SHOULD BE EITHER 'PUMP' OR 'CASH OUT'. ONLY TYPE ONE OF THOSE PHRASES. NOTHING ELSE.
                """

            action = chat_with_ollama(prompt, balloon_id).strip().lower()
            
            if action == "cash out" or action == "cashout" or action == "cashing out" or action== "cashed out" or action == "cashedout" or action == "cashingout":
                # Save the money and move to the next balloon
                balloon['status'] = 'cashout'
                balloon['earned'] = accumulated_money
                balloon['cashout'] = True
                break
            
            # Random chance for the balloon to burst
            if random.random() < 0.1:  # 10% chance of bursting
                is_burst = True
                balloon['earned'] = 0  # All money is lost
                balloon['status'] = 'burst'
                break
            
            # The balloon is pumped, increment the money
            accumulated_money += 1
            balloon['pumps'] += 1
        
        balloon['earned'] = accumulated_money
        print("*************************************")
        
        game_results.append({
            'balloon_id': balloon_id,
            'earned': balloon['earned'],
            'status': balloon['status'],
            'pumps': balloon['pumps'],
            'cashout': balloon['cashout']
        })

    # Calculate total earned money across all balloons
    total_earned = sum(result['earned'] for result in game_results)
    print(f"Total money earned: ${total_earned}")
    
    # Save the game results to a CSV file
    save_game_results_to_csv(game_results)
    return total_earned

def save_game_results_to_csv(game_results):
    """Save the game results to a CSV file."""
    with open('bart_game_results_mistral.csv', mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=['balloon_id', 'earned', 'status', 'pumps', 'cashout'])
        writer.writeheader()
        for result in game_results:
            writer.writerow(result)

# Run the BART game simulation
if __name__ == "__main__":
    total_money_earned = play_bart_game()
    print(f"Game Over! The total money earned from 1000 balloons is: ${total_money_earned}")
